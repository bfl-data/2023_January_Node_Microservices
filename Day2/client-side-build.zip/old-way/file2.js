// var dev2;

// (function(ns){
//     function hello() {
//         console.log("Hello from File Two!");
//     }

//     ns.hello = hello;
// })(dev2 = dev2 || {});

// ----------------

var dev2 = (function () {
    function hello() {
        console.log("Hello from File Two!");
    }

    function hey() {
        console.log("Hey There!");
    }

    return { hello };
})();