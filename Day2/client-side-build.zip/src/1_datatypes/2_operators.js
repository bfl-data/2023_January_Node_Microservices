// We cannot specify the type while declaring the variable
// Type of the variable will be implicitly defined at runtime
// We can provide any value to any variable
// We can use any operator with any operand type

// var r1 = 10 + true;
// console.log(r1);

// var r2 = 10 * true;
// console.log(r2);

// var r3 = 10 * "abc";
// console.log(r3);

// console.log(true && "abc");

// console.log(true ? "abc" : "xyz");
// console.log(false ? "abc" : "xyz");

// console.log(true && "abc" || "xyz");
// console.log(false && "abc" || "xyz");

// <h2 className={isValid() && 'text-success' || 'text-danger'}></h2>

var obj;
// var obj = undefined;
// var obj = null;
// var obj = { id: 1 };

// if ((obj == null) || (obj == undefined))
//     console.error("object is null or undefined");
// else
//     console.log("object is: ", obj);

// if (!obj)
//     console.error("object is null or undefined");
// else
//     console.log("object is: ", obj);

// console.log(obj);
// console.log(Boolean(obj));
// console.log(Boolean(""));
// console.log(Boolean(0));
// console.log(Boolean(1));
// console.log(Boolean(-1));
// console.log(Boolean("abc"));

// ------------------------------------------

// let a = 10;
// let b = "10";

// console.log(typeof a);
// console.log(typeof b);

// console.log(a == b);                // Abstract Equality
// console.log(a === b);                // Strict Equality


let a = { id: 1 };
let b = { id: 1 };

console.log(a == b);                // Abstract Equality
console.log(a === b);                // Strict Equality

let c = b;

console.log(c == b);                // Abstract Equality
console.log(c === b);                // Strict Equality