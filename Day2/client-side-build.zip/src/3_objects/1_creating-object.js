// var obj1 = null;
// console.log(obj1);
// console.log(typeof obj1);

// var obj2 = new Object();
// console.log(obj2);
// console.log(typeof obj2);

// var obj3 = Object();
// console.log(obj3);
// console.log(typeof obj3);

// var obj4 = {};
// console.log(obj4);
// console.log(typeof obj4);

// ------------------------

var person = {
    id: 1,
    name: "Manish",
    address: {
        city: "Pune",
        state: "MH"
    },
    display: function () {
        console.log(JSON.stringify(this));
    }
};

console.log(person);
console.log(typeof person);

var person_json = JSON.stringify(person);

console.log(person_json);
console.log(typeof person_json);

console.log(person.id);
console.log(person["id"]);
console.log(person_json.id);
console.log(person_json["id"]);

var p = JSON.parse(person_json);

console.log(p);
console.log(typeof p);
console.log(p.id);
console.log(p["id"]);