var express = require('express');
var router = express.Router();

const userCtrl = require('../controllers/user-controller');

router.get('/', userCtrl.getAll);

router.post('/', userCtrl.create);

module.exports = router;
