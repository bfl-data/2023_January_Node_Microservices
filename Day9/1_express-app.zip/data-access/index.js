const User = require('../models/User');

module.exports = class UserDAO {
    static async getAllUsers() {
        try {
            const allUsers = await User.find();
            return allUsers;
        } catch (error) {
            console.log(`Could not fetch users ${error}`);
        }
    }

    static async createUser(data) {
        try {
            const user = {
                id: data.empid,
                name: data.empname
            };
            const response = await new User(user).save();
            return response;
        } catch (error) {
            console.log(`Could not fetch users ${error}`);
        }
    }
}