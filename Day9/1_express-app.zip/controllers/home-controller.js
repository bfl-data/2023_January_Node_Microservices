// exports.index = function(req, res, next) {
//     res.render('home/index', { title: 'Express' });
// }

class HomeController {
    index(req, res, next) {
        res.render('home/index', { title: 'Express' });
    }
}

module.exports = new HomeController();