const UserDAO = require('../data-access/index');

class UserController {
    async getAll(req, res, next) {
        try {
            const users = await UserDAO.getAllUsers();
            if (!users) {
                res.status(404).json("Users not found.");
            }
            res.json(users);
        } catch (err) {
            res.status(500).json({ error: err });
        }
    }

    async create(req, res, next) {
        try {
            const createdUser = await UserDAO.createUser(req.body);
            res.json(createdUser);
        } catch (err) {
            res.status(500).json({ error: err });
        }
    }
}

module.exports = new UserController();