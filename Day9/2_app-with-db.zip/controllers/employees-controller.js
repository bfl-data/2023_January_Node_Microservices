const DAO = require("../data-access/employee-dao");

exports.index = (req, res) => {
    DAO.getAllEmployees().then(result => {
        res.render("employees/index", { pageTitle: "Employees View", empList: result, message: "" });
    }).catch(eMsg => {
        res.render("employees/index", { pageTitle: "Employees View", empList: null, message: eMsg });
    });
}

exports.details = (req, res) => {
    var _id = req.params.rid;
    DAO.getEmployee(_id).then(result => {
        res.render("employees/details", { pageTitle: "Employee Details View", employee: result, message: "" });
    }, eMsg => {
        res.render("employees/details", { pageTitle: "Employee Details View", employee: null, message: eMsg });
    });
}

exports.create_get = (req, res) => {
    res.render("employees/create", { pageTitle: "Create Employees View" });
}

exports.create_post = async (req, res) => {
    var { eid, ename } = req.body;
    var employee = { id: parseInt(eid), name: ename };

    try {
        await DAO.createEmployee(employee)
        res.redirect('/employees');
    } catch (eMsg) {
        res.render("employees/create", { pageTitle: "Create Employee View", employee: employee, message: eMsg });
    }
}

exports.edit_get = (req, res) => {
    var _id = req.params.rid;
    DAO.getEmployee(_id).then(result => {
        res.render("employees/edit", { pageTitle: "Employee Edit View", employee: result, message: "" });
    }, eMsg => {
        res.render("employees/edit", { pageTitle: "Employee Edit View", employee: result, message: eMsg });
    });
}

exports.edit_post = (req, res) => {
    var _id = req.params.rid;
    var { eid, ename } = req.body;
    var employee = { id: parseInt(eid), name: ename };

    DAO.updateEmployee(_id, employee).then(result => {
        res.redirect('/employees');
    }, eMsg => {
        res.render("employees/edit", { pageTitle: "Employee Edit View", employee: employee, message: eMsg });
    });
}

exports.delete_get = (req, res) => {
    var _id = req.params.rid;
    DAO.getEmployee(_id).then(result => {
        res.render("employees/delete", { pageTitle: "Employee Delete View", employee: result, message: "" });
    }, eMsg => {
        res.render("employees/delete", { pageTitle: "Employee Delete View", employee: result, message: eMsg });
    });
}

exports.delete_post = (req, res) => {
    var _id = req.params.rid;

    DAO.deleteEmployee(_id).then(result => {
        res.redirect('/employees');
    }, eMsg => {
        res.render("employees/delete", { pageTitle: "Employee Delete View", employee: employee, message: eMsg });
    });
}