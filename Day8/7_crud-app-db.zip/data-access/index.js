const {MongoClient} = require('mongodb');
const client = new MongoClient('mongodb://127.0.0.1:27017')

exports.getAllEmployees = async function () {
    try {
        await client.connect();
        const db = client.db('employeesDB');
        const collection = db.collection('employees');
        const employees = collection.find().toArray();
        return await employees;
    } catch(err) {
        throw new Error(err);
    } finally {
        client.close();
    }
}

exports.getEmployee = function (id) {
    return new Promise((resolve, reject) => {
        if (employees.length)
            resolve(employees.find(e => e.id === parseInt(id)));
        else
            reject("Employee not found");
    });
}

exports.insertEmployee = async function (employee) {
    try {
        await client.connect();
        const db = client.db('employeesDB');
        const collection = db.collection('employees');
        const insertedEmployee = await collection.insertOne(employee);
        return insertedEmployee;
    } catch(err) {
        throw new Error(err);
    } finally {
        client.close();
    }
}

exports.updateEmployee = function (employee) {
    return new Promise((resolve, reject) => {
        var itemIndex = employees.findIndex(e => e.id === parseInt(employee.id));
        var tempEmployees = [...employees];
        tempEmployees.splice(itemIndex, 1, { ...employee });
        employees = [...tempEmployees];

        writeData(employees).then(data=>{
            employees = data;
            resolve(employees.find(e => e.id === Number(employee.id)));
        }, err=>{
            reject(err);
        })
    });
}

exports.deleteEmployee = function (id) {
    return new Promise((resolve, reject) => {
        employees = [...employees.filter(e => e.id !== parseInt(id))];
        
        writeData(employees).then(data=>{
            employees = data;
            resolve("Success, Delete Employee");
        }, err=>{
            reject(err);
        })
    });
}