class Employee {
    constructor(id, name) {
        this._id = parseInt(id);
        this._name = name;
    }
}