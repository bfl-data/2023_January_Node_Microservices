exports.index = (req, res, next) => {
    res.render("home/index", { pageTitle: "Index" });
}

exports.contacts = (req, res) => {
    res.render("home/contacts", { pageTitle: "Contacts View" });
}