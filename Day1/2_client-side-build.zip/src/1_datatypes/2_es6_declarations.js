// let a = 10;
// console.log("a is:", a);

// a = 10;
// console.log("a is:", a);
// let a;

// let a = 10;
// console.log(a);
// console.log(typeof a);

// a = "Hello";
// console.log(a);
// console.log(typeof a);

// Error: Identifier 'a' has already been declared.
// let a = 10;
// let a = "Hello";
// console.log(a);
// console.log(typeof a);

// -----------------------------------
// Global Scope (To the File)
// Local Scope (Function Scope)
// Block Scope

// var a = 10;

// function test() {
//     if (true) {
//         let a = 100;
//         console.log("Inside if block, a is:", a);
//     }
//     console.log("Inside Fn, a is:", a);
// }

// test();
// console.log("Outside Fn, a is:", a);

var i = "Hello";
console.log("Before, i is:", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside Loop, i is:", i);
}

console.log("After, i is:", i);
