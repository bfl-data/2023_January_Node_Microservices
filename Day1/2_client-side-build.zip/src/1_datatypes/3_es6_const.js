// let a;
// a = 20;
// console.log(a);

// // Missing initializer in const declaration
// // const env;
// // console.log(env);

// const env = "dev";
// console.log(env);

// Assignment to constant variable.
// env = "prod";
// console.log(env);

// if (true) {
//     const env = "prod";
//     console.log(env);
// }

const obj = { id: 1 };

console.log(obj);

obj.name = "Manish";
console.log(obj);

obj.id = 100;
console.log(obj);

delete obj.id;
console.log(obj);

// obj = {name:"Abhijeet"};
// console.log(obj);
