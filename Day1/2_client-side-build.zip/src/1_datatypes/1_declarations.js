'use strict'

// a = 10;
// console.log("a is:", a);

// var a = 10;
// console.log("a is:", a);

// --------------------- Hoisting

// a = 10;
// console.log("a is:", a);
// var a;

// console.log("a is:", a);
// var a = 10;

// // Runtime
// var a;
// console.log("a is:", a);
// a = 10;

// --------------------

// var a = 10;
// console.log(a);
// console.log(typeof a);

// a = "Hello";
// console.log(a);
// console.log(typeof a);

// --------------------

// var a = 10;
// var a = "Hello";
// console.log(a);
// console.log(typeof a);

// --------------------

// Global Scope (To the File)
// Local Scope (Function Scope)

// var a = 10;

// function test() {
//     console.log("Inside Fn, a is:", a);
// }

// test();
// console.log("Outside Fn, a is:", a);

// ------------------
// var a = 10;

// function test() {
//     var a = 100;
//     console.log("Inside Fn, a is:", a);
// }

// test();
// console.log("Outside Fn, a is:", a);

// ------------------
// var a = 10;

// function test() {
//     if (true) {
//         var a = 100;
//         console.log("Inside if block, a is:", a);
//     }
//     console.log("Inside Fn, a is:", a);
// }

// test();
// console.log("Outside Fn, a is:", a);

var i = "Hello";
console.log("Before, i is:", i);

// for (var i = 0; i < 5; i++) {
//     console.log("Inside Loop, i is:", i);
// }

// function iterate() {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is:", i);
//     }
// }

// iterate();

// IIFE - Immediatly Invoke Function Expression
(function () {
    for (var i = 0; i < 5; i++) {
        console.log("Inside Loop, i is:", i);
    }
})();

console.log("After, i is:", i);