// console.log("Hello from Main File...");

// const obj = {
//     arr: [1, 2, 3, 4, 5, 6],
//     prinrArr() {
//         console.log(...this.arr);           // Array Spread (ECMASCRIPT 2015)
//     }
// };

// obj.prinrArr();

// import './1_datatypes/1_declarations';
// import './1_datatypes/2_es6_declarations';
import './1_datatypes/3_es6_const';

// console.log("In Main, a is:", a);