module.exports = {
    servers: [
        {
            url: "http://localhost:3000/api",
            description: "Local Server"
        }
    ]
};