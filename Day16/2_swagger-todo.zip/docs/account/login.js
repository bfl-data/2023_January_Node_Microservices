module.exports = {
    post: {
        tags: ['Accounts'],
        description: "Create todo",
        operationId: 'createTodo'
    }
};