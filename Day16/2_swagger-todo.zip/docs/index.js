const account = require("./account");
const basicInfo = require("./basicInfo");
const components = require("./components");
const servers = require("./servers");
const tags = require("./tags");
const todos = require("./todos");

module.exports = {
    ...basicInfo,
    ...servers,
    ...components,
    ...tags,
    paths: { ...todos.paths, ...account.paths }
};