module.exports = {
    tags: [
        {
            name: 'Todo CRUD Operations'
        },
        {
            name: 'Accounts'
        }
    ]
};