module.exports = {
    components: {
        securitySchemes: {
            bearerAuth: {
                type: 'http',
                scheme: 'bearer',
                bearerFormat: 'JWT',
            }
        },
        schemas: {
            _id: {
                type: 'string',
                description: "Record id of a todo",
                example: "63d31b04838e0715315c5ebc"
            },
            Todo: {
                type: 'object',
                properties: {
                    _id: {
                        type: 'string',
                        description: "Record id of a todo",
                        example: "63d31b04838e0715315c5ebc"
                    },
                    id: {
                        type: 'string',
                        description: "Todo identification string",
                        example: "Task One"
                    },
                    title: {
                        type: 'string',
                        description: "Todo's Title",
                        example: "Coding in Node JS"
                    },
                    completed: {
                        type: 'boolean',
                        description: "The status of a Todo item",
                        example: false
                    }
                }
            },
            TodoInput: {
                type: 'object',
                properties: {
                    id: {
                        type: 'string',
                        description: "Todo identification string",
                        example: "Task One"
                    },
                    title: {
                        type: 'string',
                        description: "Todo's Title",
                        example: "Coding in Node JS"
                    },
                    completed: {
                        type: 'boolean',
                        description: "The status of a Todo item",
                        example: false
                    }
                }
            },
            Error: {
                type: 'object',
                properties: {
                    message: {
                        type: 'string'
                    },
                    internal_code: {
                        type: 'string'
                    }
                }
            }
        },
        responses: {
            UnauthorizedError: {
                type: 'string',
                description: "Access token is missing or invalid",
            }
        }
    },
    security: [{
        bearerAuth: []
    }]
};