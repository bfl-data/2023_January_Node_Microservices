module.exports = {
    delete: {
        tags: ['Todo CRUD Operations'],
        description: "Deleting a todo",
        operationId: 'deleteTodo',
        parameters: [
            {
                name: "_id",
                in: "path",
                schema: {
                    $ref: "#/components/schemas/_id"
                },
                required: true,
                description: "Record Id of completed todo to be deleted"
            }
        ],
        responses: {
            '200': {
                description: "Todo deleted successfully"
            },
            '404': {
                description: "Todo not found"
            },
            '500': {
                description: "Server Error"
            },
            '401': {
                $ref: '#/components/responses/UnauthorizedError'
            }
        }
    }
};