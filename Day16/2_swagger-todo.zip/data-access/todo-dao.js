const Todo = require('../models/todo');

module.exports = class TodoDAO {
    static async getAllTodos() {
        try {
            const allTodos = await Todo.find();
            return allTodos;
        } catch (error) {
            console.log(`Could not fetch Todos ${error}`);
        }
    }

    static async getTodo(recordId) {
        try {
            const singleTodo = await Todo.findById({_id: recordId});
            return singleTodo;
        } catch (error) {
            console.log(`Could not fetch Todos ${error}`);
        }
    }

    static async createTodo(todo) {
        try {
            const response = await new Todo(todo).save();
            return response;
        } catch (error) {
            console.log(`Could not create Todo ${error}`);
        }
    }

    static async updateTodo(recordId, todo) {
        try {
            const updateResponse = await Todo.findOneAndUpdate({ _id: recordId }, todo);
            return updateResponse;
        } catch (error) {
            console.log(`Could not update Todo ${error}`);
        }
    }

    static async deleteTodo(recordId) {
        try {
            const deletedResponse = await Todo.findOneAndDelete({ _id: recordId });
            return deletedResponse;
        } catch (error) {
            console.log(`Could not delete Todo ${error}`);
        }
    }
}