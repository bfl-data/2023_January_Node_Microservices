const TodoDAO = require("../data-access/todo-dao");

exports.getTodos = async (req, res) => {
    let todos = await TodoDAO.getAllTodos();
    return res.send(todos);
}

exports.getTodo = async (req, res) => {
    var _id = req.params.rid;
    const todo = await TodoDAO.getTodo(_id);

    if (!todo) {
        res.status(404);

        return res.send({
            message: "Todo cannot be found",
            internal_code: "Invalid id"
        });

    };

    return res.send(todo);
}

exports.createTodo = async (req, res) => {
    try {
        await TodoDAO.createTodo({ ...req.body });
        return res.status(201).send("Todo saved successfully");
    } catch (error) {
        return res.status(500).send(error);
    }
}

exports.updateTodo = async (req, res) => {
    var _id = req.params.rid;
    const todo = await TodoDAO.getTodo(_id);

    if (!todo) {
        return res.sendStatus(404);
    };

    try {
        await TodoDAO.updateTodo(_id, { ...req.body });
        return res.send("Todo updated");
    } catch (error) {
        res.status(500);
        return res.send(error);
    };
}

exports.deleteTodo = async (req, res) => {
    var _id = req.params.rid;
    const todo = await TodoDAO.getTodo(_id);

    if (!todo) {
        return res.sendStatus(404);
    };

    // delete the todo.
    try {
        await TodoDAO.deleteTodo(_id);
        return res.send("Todo deleted");
    } catch (error) {
        return res.sendStatus(500);
    }
}