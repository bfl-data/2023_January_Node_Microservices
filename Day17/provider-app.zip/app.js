const express = require('express');
const amqp = require("amqplib");
const app = express();
const port = process.env.PORT || 4001;

var connection, channel;

async function connectQueue() {
    try {
        connection = await amqp.connect("amqp://localhost:5672");
        console.log(`Provider Application connected to RabbitMQ`);
        channel = await connection.createChannel();
        await channel.assertQueue("test-queue");
    } catch (error) {
        console.log(error);
    }
}

async function sendData(data) {
    await channel.sendToQueue("test-queue", Buffer.from(JSON.stringify(data)));
}

app.get('/send-msg', (req, res) => {
    // res.send("Hello World!");

    const data = {
        from: "Manish Sharma",
        value: "Hello from Provider Application"
    };

    sendData(data);
    console.log("A message is sent to the queue");
    res.send("Message Sent...");
});

app.listen(port, () => {
    console.log(`Provider Application started on port ${port}`);
    connectQueue();
});