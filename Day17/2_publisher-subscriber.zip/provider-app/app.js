const express = require('express');
const amqp = require("amqplib");
const app = express();
const port = process.env.PORT || 4001;

var connection, channel;
var exchange = 'logs';

async function connectQueue() {
    try {
        connection = await amqp.connect("amqp://localhost:5672");
        console.log(`Publisher Application connected to RabbitMQ`);
        channel = await connection.createChannel();
        await channel.assertExchange(exchange, 'fanout', {
            durable: false
        });
    } catch (error) {
        console.log(error);
    }
}

async function sendData(data) {
    await channel.publish(exchange, '', Buffer.from(JSON.stringify(data)));
}

app.get('/send-msg', (req, res) => {
    // res.send("Hello World!");

    const data = {
        from: "Manish Sharma",
        value: "Hello from Publisher Application"
    };

    sendData(data);
    console.log("A message is published to the queue");
    res.send("Message Published...");
});

app.listen(port, () => {
    console.log(`Publisher Application started on port ${port}`);
    connectQueue();
});