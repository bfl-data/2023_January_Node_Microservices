const express = require('express');
const amqp = require("amqplib");
const app = express();
const port = process.env.PORT || 4002;

var connection, channel;

async function connectQueue() {
    try {
        connection = await amqp.connect("amqp://localhost:5672");
        console.log(`Reciever Application connected to RabbitMQ`);
        channel = await connection.createChannel();
        await channel.assertQueue("test-queue");
        channel.consume("test-queue", data => {
            console.log(`${Buffer.from(data.content)}`);
            // channel.ack(data);
        });
    } catch (error) {
        console.log(error);
    }
}

app.listen(port, () => {
    console.log(`Reciever Application started on port ${port}`);
    connectQueue();
});