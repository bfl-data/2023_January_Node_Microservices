function getData() {
    var promise = new Promise((resolve, reject) => {
        // Async Code
        setTimeout(function () {
            // resolve(1000);
            reject("Some Error....");
        }, 5000);
    });
    return promise;
}

var promise = getData();

// promise.then((data) => {
//     console.log("Success: ", data);
// }, (eMsg) => {
//     console.error("Error: ", eMsg);
// });

// promise.then((data) => {
//     console.log("Success: ", data);
// }).catch((eMsg) => {
//     console.error("Error: ", eMsg);
// });

// ECMASCRIPT 2018 - Promise finally
promise.then((data) => {
    console.log("Success: ", data);
}).catch((eMsg) => {
    console.error("Error: ", eMsg);
}).finally(()=>{
    console.warn("Finally will always run");
});