// import './1_objects/1_es6-static';
// import './1_objects/2_es5-inheritance';
// import './1_objects/3_es6-inheritance';

// import './2_collections/1_arrays';
// import './2_collections/2_es6-map';
// import './2_collections/3_es6-set';

// import './3_iterators/1_custom-iterable';
// import './3_iterators/2_generators';

// import './4_modules/usage';

// import './5_promise/1_creating-promise';
// import './5_promise/2_chaining-promise';
// import './5_promise/3_promise-methods';

// import './6_ajax/dom-handler';

// import './7_beyond-es6/1_es7_features';
// import './7_beyond-es6/2_es8-object-methods';
// import './7_beyond-es6/3_es8-string-padding';
// import './7_beyond-es6/4_es8_trailing_commas';
import './7_beyond-es6/es9_async-iterators';



