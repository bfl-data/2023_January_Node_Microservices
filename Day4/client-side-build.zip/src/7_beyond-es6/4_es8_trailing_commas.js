var arr = [10, 20, 30, 40, 50,];
console.log(arr);

var person = { id: 10, };
console.log(person);

function fn(a, b,) {

}

console.log(fn);

