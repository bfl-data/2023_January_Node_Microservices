// let result = Math.pow(2,4);
// console.log(result);

// // Exponentiation Operator
// let result1 = 2 ** 4;
// console.log(result1);

// let result2 = (-3) ** 4;
// console.log(result2);

// -------------------------------------

let arr = ["ReactJS", "Angular", "ExtJS"];

// Before ES7 - Problem
// if (arr.indexOf('ReactJS')) {
//     console.log("React is available...");
// } else {
//     console.error("React is not available...");
// }

// if (arr.indexOf('VueJS')) {
//     console.log("Vue is available...");
// } else {
//     console.error("Vue is not available...");
// }

if (arr.includes('ReactJS')) {
    console.log("React is available...");
} else {
    console.error("React is not available...");
}

if (arr.includes('VueJS')) {
    console.log("Vue is available...");
} else {
    console.error("Vue is not available...");
}
