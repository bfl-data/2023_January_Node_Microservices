function getAsyncIterator() {
    const arr = [1, 2, 3, 4, 5];

    return {
        next: function () {
            if (arr.length) {
                return Promise.resolve({
                    value: arr.shift(),
                    done: false
                });
            } else {
                return Promise.resolve({
                    done: true
                });
            }
        }
    };
}

// var myIterable = {
//     [Symbol.asyncIterator]: getAsyncIterator
// };

// // for-await-of
// (async function () {
//     for await (const item of myIterable) {
//         console.log(item);
//     }
// })();


var a=10;

// if (a)
//     console.log(a.toFixed(2));

// if (a !== undefined)
//     console.log(a.toFixed(2));

console.log(a?.toFixed(2));

console.log(a ?? 'hello');