class Queue {
    constructor() {
        this._dataArray = [];
    }

    push(data) {
        this._dataArray.push(data);
    }

    pop() {
        return this._dataArray.shift();
    }

    [Symbol.iterator]() {
        let i = 0;
        const self = this;

        return {
            next: function () {
                let v, d = true;

                if (self._dataArray[i] !== undefined) {
                    v = self._dataArray[i];
                    d = false;
                    i += 1;
                }

                return {
                    done: d,
                    value: v
                };
            }
        };
    }
}

let ordersQ = new Queue();

ordersQ.push("Order Id: 1");
ordersQ.push("Order Id: 2");
ordersQ.push("Order Id: 3");

// console.log(ordersQ.pop());
// console.log(ordersQ.pop());
// console.log(ordersQ.pop());

for (const item of ordersQ) {
    console.log(item);
}

// console.log(ordersQ);

// var it = ordersQ[Symbol.iterator];
// console.log(it);