// function getId() {
//     console.log("getId Executed....");
// }

// function* getIdGen() {
//     console.log("getId Generator Executed....");
// }

// getId();
// getIdGen();

// -----------------------------
// function* getIdGen() {
//     console.log("getId Generator Executed....");
// }

// var obj = getIdGen();
// console.log(obj.next());

// -----------------------------
// function* getIdGen() {
//     yield 1;
//     yield 2;
//     yield 3;
//     console.log("getId Generator Last line Executed....");
// }

// var obj = getIdGen();
// console.log(obj.next());
// console.log(obj.next());
// console.log(obj.next());
// console.log(obj.next());

// -----------------------------

class Queue {
    constructor() {
        this._dataArray = [];
    }

    push(data) {
        this._dataArray.push(data);
    }

    pop() {
        return this._dataArray.shift();
    }

    // *[Symbol.iterator]() {
    //     for (let i = 0; i < this._dataArray.length; i++) {
    //         yield this._dataArray[i];
    //     }
    // }

    *[Symbol.iterator]() {
        yield* this._dataArray;
    }
}

let ordersQ = new Queue();

ordersQ.push("Order Id: 1");
ordersQ.push("Order Id: 2");
ordersQ.push("Order Id: 3");

for (const item of ordersQ) {
    console.log(item);
}