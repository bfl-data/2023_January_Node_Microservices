// // console.log("Hello World!");

// // console.log(process.release.lts);
// // console.log(process.cwd());
// // console.log(process.stdout);

// // console.log(__filename);
// // console.log(__dirname);

// // console.log(require);

// // console.log(module);

// function add(x = 0, y = 0) {
//     return x + y;
// }

// console.log(add(2, 3));
// console.log(add(2));
// console.log(add());

// // const Person = (function () {
// //     function Person() {
// //         this.name = "na";
// //     }

// //     Person.prototype.getName = function () {
// //         return this.name;
// //     }

// //     Person.prototype.setName = function (value) {
// //         this.name = value;
// //     }

// //     return Person;
// // })();

// class Person {
//     constructor() {
//         this.name = "na";
//     }

//     getName() {
//         return this.name;
//     }

//     setName(value) {
//         this.name = value;
//     }
// }

// var p1 = new Person();
// console.log(p1.getName());
// p1.setName("Manish");
// console.log(p1.getName());


var o1 = { id: 1, address: { city: "Pune" } };
var o2 = Object.create(o1);

// var o3 = JSON.parse(JSON.stringify(o1));
// var o2 = Object.create(o3);

console.log(o1);
console.log(o2.__proto__);

o1.address.city = "Mumbai";
o1.id = 1000;

console.log(o1);
console.log(o2.__proto__);

console.log(o2.__proto__ === o1);
