// Import an entire module for side effects only, without importing anything. 
// This runs the module's global code, but doesn't actually import any values.
// require('./lib.js');

// const lib = require('./lib.js');
// console.log(lib);
// console.log(lib.firstname);
// console.log(lib.lastname);
// console.log(lib.hello("From App Module"));

// const lib = require('./lib.js');
// var emp = new lib.Employee(1, "Manish");

// const { Employee } = require('./lib.js');
// var emp = new Employee(1, "Manish");

// console.log(emp.Id);
// console.log(emp.Name);

// emp.Id = 1000;
// emp.Name = "Abhijeet";

// console.log(emp.Id);
// console.log(emp.Name);

const Employee = require('./lib.js');
var emp = new Employee(1, "Manish");

console.log(emp.Id);
console.log(emp.Name);

emp.Id = 1000;
emp.Name = "Abhijeet";

console.log(emp.Id);
console.log(emp.Name);
