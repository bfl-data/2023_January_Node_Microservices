// // console.log("Hello from Lib...");
// // console.log(module);

// // var fname = "Manish";
// // module.exports = fname;

// // var lname = "Sharma";
// // module.exports = lname;

// // var fname = "Manish";
// // var lname = "Sharma";
// // module.exports = { fname, lname };

// // ------------------------ Named Exports
// // var fname = "Manish";
// // var lname = "Sharma";

// // module.exports.firstname = fname;
// // module.exports.lastname = lname;

// // module.exports.hello = function (message) {
// //     return `From Lib - ${message.toUpperCase()}`
// // }

// // ------------------------ Named Exports
// var fname = "Manish";
// var lname = "Sharma";

// exports.firstname = fname;
// exports.lastname = lname;

// exports.hello = function (message) {
//     return `From Lib - ${message.toUpperCase()}`
// }

// // class Employee {
// //     constructor(id, name) {
// //         this._id = id;
// //         this._name = name;
// //     }

// //     get Name() {
// //         return this._name;
// //     }

// //     set Name(value) {
// //         this._name = value;
// //     }

// //     get Id() {
// //         return this._id;
// //     }

// //     set Id(value) {
// //         this._id = value;
// //     }
// // }

// // exports.Employee = Employee;

// exports.Employee = class {
//     constructor(id, name) {
//         this._id = id;
//         this._name = name;
//     }

//     get Name() {
//         return this._name;
//     }

//     set Name(value) {
//         this._name = value;
//     }

//     get Id() {
//         return this._id;
//     }

//     set Id(value) {
//         this._id = value;
//     }
// }

module.exports = class {
    constructor(id, name) {
        this._id = id;
        this._name = name;
    }

    get Name() {
        return this._name;
    }

    set Name(value) {
        this._name = value;
    }

    get Id() {
        return this._id;
    }

    set Id(value) {
        this._id = value;
    }
}