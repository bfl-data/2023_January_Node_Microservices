class Employee{
    constructor(id, name) {
        this._id = id;
        this._name = name;
    }

    get Name() {
        return this._name;
    }

    set Name(value) {
        this._name = value;
    }

    get Id() {
        return this._id;
    }

    set Id(value) {
        this._id = value;
    }
}

export default Employee;