import Employee from "./lib.mjs";
var emp = new Employee(1, "Manish");

console.log(emp.Id);
console.log(emp.Name);

emp.Id = 1000;
emp.Name = "Abhijeet";

console.log(emp.Id);
console.log(emp.Name);