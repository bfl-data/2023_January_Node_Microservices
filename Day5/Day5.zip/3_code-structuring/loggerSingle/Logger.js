// class Logger {
//     log(message) {
//         console.log(`${message}, logged using Logger class Method`);
//     }
// }

// module.exports = Logger;

// ------------------------------------------------
// class Logger {
//     log(message) {
//         console.log(`${message}, logged using Logger class Method`);
//     }
// }

// class LoggerSingleton {
//     constructor() {
//         throw new Error("Use getInstance to get the instance of Logger");
//     }

//     static getInstance() {
//         if (!Logger.instance)
//             Logger.instance = new Logger();

//         return Logger.instance;
//     }
// }

// module.exports = LoggerSingleton;

// ------------------------------------------------
class Logger {
    log(message) {
        console.log(`${message}, logged using Logger class Method`);
    }
}

module.exports = new Logger();