const Logger = require('./Logger');
let instance = new Logger();

module.exports = instance;

// const Logger = require('./Logger');
// let instance = new Logger();

// module.exports.getLogger = function () {
//     return instance;
// };

// -------------------------------------------
// const Logger = require('./Logger');
// let instance;

// module.exports.getLogger = function () {
//     if(!instance)
//         instance = new Logger();

//     return instance;
// };

// ---------------------------------------------
// const Logger = require('./Logger');

// module.exports.getLogger = (function(){
//     let instance = new Logger();

//     return function() {
//         return instance;
//     }
// })();