// // require('./logger.js');
// // require('./logger.js');

// const logger1 = require('./logger.js');
// const logger2 = require('./logger.js');

// console.log(logger1 === logger2);

// const logger1 = require('./logger');
// const logger2 = require('./logger');

// console.log(logger1 === logger2);

// ------------------------------------------------

// const logger1 = require('./logger');
// const logger1 = require('./logger/myLogger');
// const logger1 = require('./logger/index');
// const logger1 = require('./logger');

// const loggerService = require('./loggerService');
// loggerService.log("Hello from App Module");

// const loggerSingle = require('./loggerSingle');
// const logger = loggerSingle.getLogger();
// logger.log("Hello from App Module");

// const logger1 = loggerSingle.getLogger();
// const logger2 = loggerSingle.getLogger();

// console.log(logger1 === logger2);       // Expected is true

// ----------------------------
// const loggerSingle = require('./loggerSingle');
// loggerSingle.log("Hello from App Module");

// const loggerSingle1 = require('./loggerSingle');
// const loggerSingle2 = require('./loggerSingle');

// console.log(loggerSingle1 === loggerSingle2);

// ---------------------------

// const LoggerSingleton = require('./loggerSingle/Logger');

// // var l1 = new Logger();
// // var l2 = new Logger();

// var l1 = LoggerSingleton.getInstance();
// var l2 = LoggerSingleton.getInstance();

// console.log(l1);
// console.log(l2);
// console.log(l1 === l2);

const LoggerSingle = require('./loggerSingle/Logger');

LoggerSingle.log("Hello from App");