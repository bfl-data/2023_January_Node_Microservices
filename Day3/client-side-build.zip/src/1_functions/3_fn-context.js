// 'use strict'

// // In ES ‘this’ refers to the parent of the function and
// // the object through which the function was called

// function test1() {
//     console.log(this);
// }

// test1();

// const test2 = function () {
//     console.log(this);
// }

// test2();

// // In ES6, arrow functions use lexical scoping — ‘this’ refers to it’s current surrounding 
// // scope and no further.

// const test3 = () => {
//     console.log(this);
// }

// test3();

// setInterval(test3, 2000);

// console.log("Inside File: ", this);
// var self = this;

// const test3 = () => {
//     console.log(self === this);
// }

// test3();

// ---------------------------------------

// var person = {
//     age: 0,
//     growOld: function () {
//         console.log("Context of growOld is: ", this);
//         this.age += 1;
//     }
// };

// console.log(person.age);

// person.growOld();
// console.log(person.age);

// person.growOld();
// console.log(person.age);

// person.growOld();
// console.log(person.age);

// person.growOld();
// console.log(person.age);

// ---------------------------------------------------

// var btn = document.createElement("button");
// btn.className = "btn btn-primary btn-block";
// btn.innerHTML = "Click";

// var btnArea = document.getElementById("btnArea");
// btnArea.appendChild(btn);

// btn.addEventListener("click", person.growOld.bind(person));

// setInterval(person.growOld.bind(person), 2000);

// --------------------------------------------------- Context Switching

// function check(x, y) {
//     console.log(x, y);
//     console.log(this);
// }

// var p1 = {
//     id: 1
// }

// check(20, 30);
// check.call(p1, 21, 31);
// check.apply(p1, [22, 32]);

// var fn = check.bind(p1, 23, 33);
// fn();

// --------------------------------------------------- 

// function Person() {
//     this.age = 0;
//     this.growOld = function () {
//         console.log(this);
//         this.age += 1;
//     }
// }

// function Person() {
//     var self = this;
//     self.age = 0;
//     self.growOld = function () {
//         console.log(this);
//         console.log(self);
//         self.age += 1;
//     }
// }

// --------------------------------------------------------------
// function Person() {
//     this.age = 0;
//     this.growOld = () => {
//         console.log(this);
//         this.age += 1;
//     }
// }

// var p1 = new Person();

// var btn = document.createElement("button");
// btn.className = "btn btn-primary btn-block";
// btn.innerHTML = "Click";

// var btnArea = document.getElementById("btnArea");
// btnArea.appendChild(btn);

// // btn.addEventListener("click", p1.growOld.bind(p1));
// btn.addEventListener("click", p1.growOld);

// --------------------------------------------------------------

// var p1 = {
//     id: 1,
//     name: "Manish",
//     toJson: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet",
//     toJson: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// p1.toJson();
// p2.toJson();

// --------------------------- Functiuon Borrowing
// function toJson() {
//     console.log(JSON.stringify(this));
// }

// var p1 = {
//     id: 1,
//     name: "Manish"
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet"
// };

// // toJson.call(p1);
// // toJson.call(p2);

// p1.toJson = toJson.bind(p1);
// p2.toJson = toJson.bind(p2);

// p1.toJson();
// p2.toJson();

// ---------------------

var p1 = {
    id: 1,
    name: "Manish",
    toJson: function() {
        console.log(JSON.stringify(this));
    }
};

var p2 = {
    id: 2,
    name: "Abhijeet"
};

p2.toJson = p1.toJson.bind(p2);

p1.toJson();
p2.toJson();