// function add(x, y) {
//     return x + y;
// }

// function sub(x, y) {
//     return x - y;
// }

// // I want to log the arguments passed to the add and sub function
// // Where should we write the code?

// console.log(add(2, 3));
// console.log(sub(20, 3));

// ------------------------------------

// function add(x, y) {
//     console.log(`add call with args, ${x}, ${y}`);
//     return x + y;
// }

// function sub(x, y) {
//     console.log(`sub call with args, ${x}, ${y}`);
//     return x - y;
// }

// console.log(add(2, 3));
// console.log(sub(20, 3));

// ------------------------------------

// function add(x, y) {
//     log(`add call with args, ${x}, ${y}`);
//     return x + y;
// }

// function sub(x, y) {
//     log(`sub call with args, ${x}, ${y}`);
//     return x - y;
// }

// function log(message) {
//     console.log(message);
// }

// console.log(add(2, 3));
// console.log(sub(20, 3));

// ------------------------------------

// function add(x, y) {
//     log(`add call with args, ${x}, ${y}`);
//     return x + y;
// }

// function sub(x, y) {
//     log(`sub call with args, ${x}, ${y}`);
//     return x - y;
// }

// function log(message) {
//     console.log(message);
// }

// console.log(add(2, 3));
// console.log(sub(20, 3));

// ------------------------------------

// function add(x, y) {
//     return x + y;
// }

// function sub(x, y) {
//     return x - y;
// }

// // HOF - Higher Order Function
// function logDecorator(fn) {
//     return function (...args) {
//         console.log(`${fn.name} call with args, ${args}`);
//         let result = fn.apply(this, args);
//         return result;
//     }
// }

// var addWithLogger = logDecorator(add);
// var subWithLogger = logDecorator(sub);

// console.log(addWithLogger(2, 3));
// console.log(subWithLogger(20, 3));

// ------------------------------------ Future Change

// @logDecorator
// function add(x, y) {
//     return x + y;
// }

// @logDecorator
// function sub(x, y) {
//     return x - y;
// }

// // HOF - Higher Order Function
// function logDecorator(fn) {
//     return function (...args) {
//         console.log(`${fn.name} call with args, ${args}`);
//         let result = fn.apply(this, args);
//         return result;
//     }
// }

// console.log(add(2, 3));
// console.log(sub(20, 3));

// ----------------------------------------------------------------------
// Handle Exceptions of the code using Higher Order Function

function m1(x, y) {
    throw Error("Invalid Arguments....");
}

// try {
//     m1(20, 30);
// } catch (e) {
//     console.error(e.message);
// }

function errorHandler(fn) {
    return function (...args) {
        try {
            let result = fn.apply(this, args);
            return result;
        } catch (e) {
            console.error(e.message);
        }
    }
}

(errorHandler(m1))(20, 30);
(errorHandler(m1))(21, 30);
(errorHandler(m1))(22, 30);