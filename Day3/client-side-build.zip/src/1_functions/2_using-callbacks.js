// // Dev 1
// function add(x, y) {
//     return x + y;
// }

// // Dev 2
// function showResult(result) {
//     document.getElementById("hTwoResult").innerHTML = result;
// }

// var result = add(2, 3);
// showResult(result);

// --------------------------------------------

// // Dev 1
// function showResult(result) {
//     document.getElementById("hTwoResult").innerHTML = result;
// }

// function add(x, y) {
//     var result = x + y;
//     showResult(result);
// }

// // Dev 2 - UI
// add(2, 3);

// --------------------------------------------

// // Dev 1
// function add(x, y, cb) {
//     var result = x + y;
//     cb(result);
// }

// // Dev 2 - UI
// function showResult(result) {
//     document.getElementById("hTwoResult").innerHTML = result;
// }

// add(2, 3, showResult);

// add(20, 30, function (r) {
//     document.getElementById("resultSpan").innerHTML = r;
// });

// add(21, 32, r => {
//     document.getElementById("resultSpan1").innerHTML = r;
// });

// // -------------------------------------

// function getString() {
//     const strArr = ["NodeJS", "ReactJS", "Angular", "ExtJS", "jQuery"];
//     var str = strArr[Math.floor(Math.random() * strArr.length)];
//     return str;
// }

// // var s = getString();
// // console.log(s);

// setInterval(function () {
//     var s = getString();
//     console.log(s);
// }, 2000);

// Call 1 - 1000 ms
// Call 2 - 3000 ms
// Call 3 - 1000 ms

// -------------------------------------

function pushString(cb) {
    const strArr = ["NodeJS", "ReactJS", "Angular", "ExtJS", "jQuery"];
    setInterval(function () {
        var str = strArr[Math.floor(Math.random() * strArr.length)];
        cb(str);
    }, 2000);
}


pushString((s) => { console.log("S1:", s); });
// pushString((s) => { console.log("S2:", s); });

console.log("Last Line");