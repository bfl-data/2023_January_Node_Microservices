// import './1_functions/1_fn-as-arguments';
// import './1_functions/2_using-callbacks';
// import './1_functions/3_fn-context';
// import './1_functions/4_fn-currying';
// import './1_functions/5_hof';

// import './2_objects/1_symbol-as-keys';
// import './2_objects/2_object-type';
// import './2_objects/3_object-methods';
// import './2_objects/4_custom-type';
// import './2_objects/5_using-prototypes';
// import './2_objects/6_es6-class';
// import './2_objects/7_compare';
// import './2_objects/8_es5-properties';
import './2_objects/9_es6-property';
