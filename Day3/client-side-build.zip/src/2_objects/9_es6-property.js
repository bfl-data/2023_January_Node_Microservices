class Person {
    constructor(name) {
        this._name = name;
    }

    get Name() {
        return this._name;
    }

    set Name(value) {
        this._name = value;
    }
}

var p1 = new Person("Manish");
console.log(p1.Name);
p1.Name = "Abhijeet";
console.log(p1.Name);