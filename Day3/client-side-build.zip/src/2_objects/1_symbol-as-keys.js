// var person = {
//     id: 1,
//     name: "Manish",
//     address: {
//         city: "Pune"
//     },
//     username: "ManishS",
//     password: "ManishS"
// }

var password = Symbol("password");

var person = {
    id: 1,
    name: "Manish",
    address: {
        city: "Pune"
    },
    [Symbol("username")]: "ManishS",
    [password]: "ManishPwd"
}

var person_json = JSON.stringify(person);
console.log(person_json);

console.log(person);
console.log(person[password]);
console.log(person[Symbol("username")]);