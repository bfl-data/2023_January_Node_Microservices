// Create a BankAccount Class with bankName and accName as data properties and create accessor properties 
// to access the data outside using instance.