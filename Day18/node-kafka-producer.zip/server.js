const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const kafka = require('kafka-node');

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

try {
    const Producer = kafka.Producer;
    const client = new kafka.KafkaClient('localhost:2181');
    const producer = new Producer(client);

    const kafka_topic = 'feed-service';

    producer.on('ready', async function() {
        console.log('Kafka Producer is Ready');
    });

    producer.on('error', function (err) {
        console.log(err);
        console.log('[kafka-producer -> ' + kafka_topic + ']: connection errored');
        throw err;
    });

    mongoose.set('strictQuery', true);
    mongoose.connect(`mongodb://127.0.0.1:27017/nodekafkauserdb`).then((err, res) => {
        console.log('MongoDB connected successfully');
        require('./routes')(app, producer, kafka_topic);
    });
} catch (e) {
    console.log(e);
}

app.listen(4567, () => {
    console.log('User Service is listening to port 4567')
});
