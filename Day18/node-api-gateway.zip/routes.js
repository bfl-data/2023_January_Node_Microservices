const routes = [
    {
        url: '/producer',
        proxy: {
            target: "http://localhost:4567",
            changeOrigin: true,
            pathRewrite: {
                [`^/producer`]: ''
            }
        }
    },
    {
        url: '/consumer',
        proxy: {
            target: "http://localhost:4568",
            changeOrigin: true,
            pathRewrite: {
                [`^/consumer`]: ''
            }
        }
    }
];

exports.routes = routes;