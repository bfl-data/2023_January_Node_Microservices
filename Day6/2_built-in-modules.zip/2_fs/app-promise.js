const fs = require('fs').promises;

(async function () {
    try {
        const data = await fs.readFile('./file1.txt', 'utf-8');
        console.log(data);
    } catch (err) {
        console.log(`Got an error: ${err.message}`);
    }
})();

// async function readFile() {
//     try {
//         const data = await fs.readFile('./file1.txt', 'utf-8');
//         console.log(data);
//     } catch (err) {
//         console.log(`Got an error: ${err.message}`);
//     }
// }

// readFile();

console.log("\n--------------End of Code-----------\n");
