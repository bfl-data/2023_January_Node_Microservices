const fsPromises = require('fs').promises;
const readline = require('readline');

const writeFileAsync = async (data) => {
    try {
        await fsPromises.writeFile('assign-file.txt', data, 'utf-8');
        console.log('File is written successfully.');
    } catch (err) {
        throw err;
    }
}

const takeInput = (message) => {
    const rl = readline.createInterface({
        input: process.stdin,       // Readstream
        output: process.stdout      // Writestream
    });

    return new Promise((resolve) => {
        rl.question(message, (input) => {
            rl.close();
            resolve(input);
        });
    })
}

(async function () {
    try {
        var n1 = await takeInput("Enter the data: ");
        await writeFileAsync(n1);
    } catch (err) {
        console.log(err);
    }
})();