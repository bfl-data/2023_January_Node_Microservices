const emailClient = require('./Email');
const smsClient = require('./SMS');

module.exports = { emailClient, smsClient };