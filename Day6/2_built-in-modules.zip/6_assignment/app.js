const Account = require('./Account');
const utility = require('./utilities');

let a1 = new Account(1, 1000, 6);

// Code to Display message on the console
a1.on('depositSuccess', (balance)=>{
    console.log("\nAmount Deposited Successfully...");
    console.log(`New Account Balance is: INR ${balance}`);
});

a1.on('withdrawSuccess', (balance)=>{
    console.log("\nAmount Withdrawn Successfully...");
    console.log(`New Account Balance is: INR ${balance}`);
});

a1.on('withdrawFailure', (balance)=>{
    console.log("\nAmount Withdraw Failed...");
    console.log(`Account Balance is: INR ${balance}`);
});

// Code to send SMS
a1.on('depositSuccess', (balance)=>{
    utility.smsClient.send(`Amount Deposited - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawSuccess', (balance)=>{
    utility.smsClient.send(`Amount Withdrawn - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawFailure', (balance)=>{
    utility.smsClient.send(`Amount Withdraw Failed - Account Balance is: INR ${balance}`);
});

// Code to send Email
a1.on('depositSuccess', (balance)=>{
    utility.emailClient.send(`Amount Deposited - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawSuccess', (balance)=>{
    utility.emailClient.send(`Amount Withdrawn - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawFailure', (balance)=>{
    utility.emailClient.send(`Amount Withdraw Failed - Account Balance is: INR ${balance}`);
});

a1.deposit(1000);
a1.withdraw(2000);
a1.withdraw(1000);