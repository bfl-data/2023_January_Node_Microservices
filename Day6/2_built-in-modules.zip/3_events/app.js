const StringEmitter = require('./StringEmitter');
const sEmitter = new StringEmitter();

// var s = sEmitter.getString();
// console.log(s);

// setInterval(function () {
//     var s = sEmitter.getString();
//     console.log(s);
// }, 2000);

// ----------------------------
// sEmitter.pushString((s) => {
//     console.log(s);
// });

// sEmitter.pushString((s) => {
//     console.log("S1 - ", s);
// });

// sEmitter.pushString((s) => {
//     console.log("S2 - ", s.toUpperCase());
// });

// ------------------------------

sEmitter.on("dataEmitted", (s) => {
    console.log("S1 - ", s);
});

// sEmitter.on("dataEmitted", (s) => {
//     console.log("S2 - ", s.toUpperCase());
// });

let count = 0;

function S2(s) {
    console.log("S2 - ", s.toUpperCase());
    ++count;
    if(count > 2) {
        sEmitter.removeListener('dataEmitted', S2);
    }
}

sEmitter.on("dataEmitted", S2);