// const readline = require('readline');
// // console.log(readline);

// const rl = readline.createInterface({
//     input: process.stdin,       // Readstream
//     output: process.stdout      // Writestream
// });

// // rl.question("Enter a number: ", (input)=>{
// //     console.log(`You entered: ${input}`);
// //     rl.close();
// // });

// // console.log("\n------Last Line------\n");
// // rl.close();

// // -------------------------------------------

// // rl.question("Enter the first number: ", (input1) => {
// //     rl.question("Enter the second number: ", (input2) => {
// //         var sum = parseInt(input1) + parseInt(input2);
// //         console.log(`Result is: ${sum}`);
// //         rl.close();
// //     });
// // });

// // ---------------------------------------------------- Implement the above code using Promise

// // function enterNumberOne() {
// //     return new Promise((resolve) => {
// //         rl.question("Enter the first number: ", (input) => {
// //             var n1 = parseInt(input);
// //             resolve(n1);
// //         });
// //     })
// // }

// // function enterNumberTwo(n1) {
// //     return new Promise((resolve) => {
// //         rl.question("Enter the second number: ", (input) => {
// //             var n2 = parseInt(input);
// //             resolve([n1, n2]);
// //         });
// //     })
// // }

// // function add([n1, n2]) {
// //     var sum = n1 + n2;
// //     console.log(`Result is: ${sum}`);
// //     rl.close();
// // }

// // enterNumberOne().then(enterNumberTwo).then(add);

// // ---------------------------------------------------------

// function enterNumber(message) {
//     return new Promise((resolve) => {
//         rl.question(message, (input) => {
//             var num = parseInt(input);
//             resolve(num);
//         });
//     })
// }

// (async function () {
//     var n1 = await enterNumber("Enter the first number: ");
//     var n2 = await enterNumber("Enter the second number: ");
//     var sum = n1 + n2;
//     console.log(`Result is: ${sum}`);
//     rl.close();
// })();

const repl = require('node:repl');
console.log(repl.builtinModules);