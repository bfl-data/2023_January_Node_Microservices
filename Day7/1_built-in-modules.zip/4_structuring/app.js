const fs = require('fs');

const appHandler = (req, res) => {
    fs.readFile('./index.html', 'utf-8', (err, htmlContent) => {
        if (err) {
            res.setHeader("content-type", "text/plain");
            res.end("Page not found");
        } else {
            res.setHeader("content-type", "text/html");
            res.write(htmlContent);
            res.end();
        }
    })
}

module.exports = appHandler;